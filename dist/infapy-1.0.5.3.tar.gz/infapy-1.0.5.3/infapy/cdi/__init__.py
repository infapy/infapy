class CDI():
    def __init__(self,v3,v2,v3SessionID,v3BaseURL,v2BaseURL,v2icSessionID):
        print("Created CDI Class")
        self._v3=v3
        self._v2=v2
        self._v3SessionID = v3SessionID
        self._v3BaseURL = v3BaseURL
        self._v2BaseURL = v2BaseURL
        self._v2icSessionID = v2icSessionID
        
        