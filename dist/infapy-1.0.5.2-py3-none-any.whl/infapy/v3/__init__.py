import infapy

class V3():
    def __init__(self,v3,v3SessionID,v3BaseURL):
        print("Created V3 Class")
        self._v3=v3
        self._v3SessionID = v3SessionID
        self._v3BaseURL = v3BaseURL
     
        